---
layout: post
title: "[Facebook] Task Scheduling Question (`)"
comments: true
category: Facebook
tags: [  ]
---

### Question 

[link](http://www.itint5.com/oj/#10)

> 有n个任务需要完成（编号1到n），任务之间有一些依赖关系，如果任务a依赖于任务b和c，那么只有当任务b和任务c完成之后才能完成任务a。给定所有的依赖关系，判断这些任务是否能够完成。如果能够完成，请给出一个合法的任务完成序列。

> 样例：
>
>n=5
>
>1->2,3
>
>3->4
>
>上述样例中任务1依赖于任务2和任务3，任务3依赖于任务4，那么存在合法的任务完成序列4,3,2,1,5

### Solution

http://www.itint5.com/discuss/8/%E4%BB%BB%E5%8A%A1%E8%B0%83%E5%BA%A6java%E7%A8%8B%E5%BA%8F

### Code


