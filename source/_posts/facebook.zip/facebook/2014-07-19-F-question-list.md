---
layout: post
title: "[Facebook] F Question List"
comments: true
category: Facebook
tags: [  ]
---

### Leetcode Questions

1. Inverse Integer
1. Anagrams
1. Edit distance

### Difficult Questions

1. Binary hamming code
1. 有一个长度为n的字符串str，有非常多的关键字query（长度不超过10），需要判断每个关键字是否是str的子串。
1. Given a dictionary and some words. Check whether these words exists in the dictionary. 

