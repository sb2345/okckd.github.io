---
layout: post
title: "[CC150v4] 15.5 SQL Students Grade Database (`)"
comments: true
category: CC150v4
tags: [  ]
published: false
---

### Question

> Imagine a simple database storing information for students' grades. Design what this database might look like, and provide a SQL query to return a list of the honor roll students (top 10%), sorted by their grade point average. 

### Answer 

