---
layout: post
title: "[CC150v4] 15.4 SQL Design Company Database (`)"
comments: true
category: CC150v4
tags: [  ]
published: false
---

### Question

> Draw an entity-relationship diagram for a database with companies, people, and professionals (people who work for companies). 

### Answer 

