---
layout: post
title: "[CC150v4] 15.3 SQL Denormalization (`)"
comments: true
category: CC150v4
tags: [  ]
published: false
---

### Question

> What is denormalization? Explain the pros and cons. 

### Answer 

