---
layout: post
title: "[Thoughts] Ten years is a long time"
comments: true
category: Thoughts
tags: [thoughts]
---

### Life isn't always going along nicely. 

Remember this. 

Keep Holding On

	You're not alone, together we stand
	I'll be by your side you know I'll take your hand
	When it gets cold, and it feels like the end
	There's no place to go you know I won't give in
	(Ah, Ah) No I won't give in (Ah, Ah-Ah)

	Keep holding on
	'Cause you know we'll make it through
	We'll make it through

	Just stay strong
	'Cause you know I'm here for you
	I'm here for you

	There's nothing you can say (Nothing you can say)
	Nothing you could do (Nothing you could do)
	There's no other way when it comes to the truth so

	Keep holding on
	'Cause you know we'll make it through
	We'll make it through

	So far away, I wish you were here
	Before it's too late this could all disappear
	Before the doors close, and it comes to an end
	With you by my side I will fight and defend
	(Ah, Ah) I'll fight and defend (Ah, Ah-Ah) Yeah, Yeah

	Keep holding on (x1)

	Hear me when I say when I say "I believe"
	Nothing's gonna change nothing's gonna change destiny
	Whatever's meant to be will work out perfectly
	Yea-Eh, Yea-Eh, Yea-Eh, Yea-Eh-Ah-Ah (Ah-Ah, Ah-Ah)
	La-Da-Da-Da, La-Da-Da-Da, La-Da-Da-Da-Da-Da-Da-Da-Da

	Keep holding on(x2)
