---
layout: post
title: "[Thoughts] Some thoughts on LeetCode questions IV"
comments: true
category: Thoughts
tags: [thoughts]
---

### Some stats

I started Leetcode __4 month ago__, and I took me around __2 month__ to finish most of the questions. I spent another __1 month__ to re-solve many questions, following the instructions from NineChap. Until 2 weeks ago, there're __in total 1861 submissions (or 18 submission per day)__.

From 2 weeks ago till today, I registed a new Leetcode account and solved __144/151 questions__ using __427 submission (or 35 submissions per day)__. I will probably finish up everything in 1 or 2 days' time. 

The AC/submission rate shall be used as a benchmark for future improvement. 

### Thoughts

Keep up the hard work! 