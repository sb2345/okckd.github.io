---
layout: post
title: "[Thoughts] Some thoughts on LeetCode questions"
comments: true
category: Thoughts
tags: [thoughts]
---

### First word

__May 8th, 2014 Thursday is the historical day that a milestone is set__. I have solved more than 100 questions on leetcode!

The past 2 month have been a great training opportunity for my programming skills, and I shall definitely keep up this work. 

### Thoughts 

1. __Practice makes perfect__. Code implementation is simply a matter of experience and practice. Some questions is easy in algorithm but hard in writing code (eg. atoi). This skill is gained, not taught, so I will focus less in coding implementation in future posts. 

2. __There is just a handful of algorithms in this world__, and most question can be solved with the most standard algorithms. Keep in mind these algorithms is important. 

3. __There are sometimes brain teaser questions__ like Single Number II or Sort Colors. These question really needs a intelligent brain. 


This is all I have right now. Will update later. 
