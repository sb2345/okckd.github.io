---
layout: post
title: "[Thoughts] Who Will Remember You? "
comments: true
category: Thoughts
tags: [thoughts]
---

[Full article](http://site.douban.com/169996/widget/notes/9314124/note/429239398/)

[Link 2](http://meiwenrishang.com/post/2014-09-26/40063071403)

{% img middle /assets/images/about-success.jpg 420 %}

几米说过：“每个人都有一双翅膀；有的人长在脚上，有的人长在手上，有的人长在头上，有的人长在心上。__翅膀长在哪里，你的天赋就在哪里__。”

每个人都有自己难以启齿的一面。但是说真的，没有人会在乎你。人们不会对你的缺陷念念不忘，人们只会在你最春风得意的时候，突然想起来：“哦？那家伙不是少两根手指吗？这也能办到，好厉害……”

我的日记本上写着一句话，我想把它送给大家：__你失败一千次也不会有人记得你，因为人们只会记住你成功的一次__。
