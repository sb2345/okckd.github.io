---
layout: post
title: "[Thoughts] Some Random Thought"
comments: true
category: Thoughts
tags: [thoughts]
---

自从7月16号投了Fb，到今天一共33天。

我大概交了五六次简历。

一个面试都没有，妈的！ 