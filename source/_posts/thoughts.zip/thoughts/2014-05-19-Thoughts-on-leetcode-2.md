---
layout: post
title: "[Thoughts] Some thoughts on LeetCode questions II"
comments: true
category: Thoughts
tags: [thoughts]
---


### First word

__As of May 18th, 2014 Sunday__, I have solved __120/151 questions__ on LeetCode, plus __60+ blog posts__.

### Thoughts 

When I started doing LeetCode and try to come up with solutions, I was generally good in productivity. But recently as I start to read other people's code and try to find the best solution from the internet, I started to slow down my pace. I thought it's a good thing, because reading other people's code helps me to diverse my thinking. As a matter of fact, it really is good. However, as the number of difficult problems start to increase, I am starting to face some bottleneck with productivity. I am sometimes stuck in 1 problem for 2+ hours, and sometime I start to be bored at reading code. Maybe it's the lack of sleep, I would feel dizzy sometimes doing LeetCode. I am sure that my passion in keep doing this has never decreased, but maybe I was just trying to hard. 

__Keep in mind that learning is not always as exciting as the first few days__, and keep holding on. 
